﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core_CustomMiddleware
{
    public static  class MyMiddleware
    {
        public static async Task Middleware1(HttpContext context)
        {
            await context.Response.WriteAsync("Middleware 1 \n");
        }

        public static async Task Middleware2(HttpContext context)
        {
            await context.Response.WriteAsync("Middleware 2 \n");
        }

    }
}
