﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace Core_Exception_Handling.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> logger;

        //LOGGING CUSTOM EXCPEPTIONS 
        public HomeController(ILogger<HomeController> logger)
        {
            this.logger = logger;
        }
        public void Index()
        {
            throw new Exception("error");
        }

        public IActionResult Privacy()
        {
            return View();
        }


        //EXCEPTION HANDLING
        [AllowAnonymous]
        [Route("Error")]
        public IActionResult Error()
        {
            // Retrieve the exception Details
            var exceptionHandlerPathFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();

            ViewBag.ExceptionMessage = exceptionHandlerPathFeature.Error.Message;
            ViewBag.StackTrace = exceptionHandlerPathFeature.Error.StackTrace;

            return View("Error");
        }

        //LOGGING
        [AllowAnonymous]
        [Route("LogError")]
        public IActionResult LogError()
        {
            // Retrieve the exception Details

            var exceptionHandlerPathFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            logger.LogError($"The path {exceptionHandlerPathFeature.Path} " +
             $"threw an exception {exceptionHandlerPathFeature.Error}");
            return View();
        }
    }
}
